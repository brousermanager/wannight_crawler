from setuptools import setup

setup(
    name='wannight_database',
    version='1.4.1',
    packages=['hera', 'console_scripts', 'alembic_migrations', 'alembic_migrations/versions'],
    entry_points={
        'console_scripts': [
            'hera_console = console_scripts.console:main',
        ],
    },
    install_requires=[
        'pandas',
        'alembic',
        'fuzzywuzzy',
        'sqlalchemy',
        'python-dotenv',
        'psycopg2-binary',
        'python-Levenshtein'
    ],
    author='bro_users',
    author_email='bro.users.info@gmail.com',
    description='Libreria da usare per smanettare con il database di Wannight',
    keywords='wannight database sqlalchemy psycopg2 postgres',
    url='https://gitlab.com/brousers/wannight/wannightdatabase'
)
