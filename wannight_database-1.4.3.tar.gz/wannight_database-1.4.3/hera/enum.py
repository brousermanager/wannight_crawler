import enum

class LogType(enum.Enum):
    LOG = 'Log'
    ERROR = 'Error'


class LogProcess(enum.Enum):
    ERMES = 'Ermes'
    SIRIO = 'Sirio'
    ATHENA = 'Athena'
    APOLLO = 'Apollo'
    DIONISO = 'Dioniso'
    CERBERO = 'Cerbero'
    ARCHIMEDE = 'Archimede'


class CategoryType(enum.Enum):
    SWAG = 'Swag'
    SIRIO = 'Sirio'
    ERMES = 'Ermes'
    GOOGLE = 'Google'
    CERBERO = 'Cerbero'
    FACEBOOK = 'Facebook'


class UserStatus(enum.Enum):
    VERIFIED = 'Verified'
    NOT_VERIFIED = 'Not verified'
    PROFESSIONAL = 'Professional'


class SuggestionPlatform(enum.Enum):
    INSTAGRAM = 'Instagram'
    FACEBOOK = 'Facebook'
