from contextlib import contextmanager

from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker

from .crud import (
    _create,
    _update,
    _delete,
    _create_list,
    _delete_list,
    _delete_by_id,
    _update_by_id,
    _get_by_id,
    _delete_following_row
)
from .porting import (
    _csv_export,
    _csv_import,
    _export_future_events,
    _import_future_events
)
from .schema import Base, Event
from .validator import _validate_event

engine = None

# TODO spostare in env.py?
def set_database(url):
    global engine
    engine = create_engine(url)
    Base.metadata.create_all(engine)
    event.listen(Event, 'before_insert', validate_event)
    return engine
    # TODO: populate()

@contextmanager
def Session():
    session = sessionmaker(bind=engine)()
    try:
        yield session
    except Exception as e :
        print(e)
    finally:
        session.close()

def csv_export(path: str = None):
    _csv_export(engine, path)

def export_future_events(path: str = None):
    _export_future_events(engine, path)

def import_future_events(path: str = None):
    _import_future_events(Session, path)

def csv_import(path: str):
    _csv_import(engine, Session, path)

def validate_event(mapper, connection, target):
    if _validate_event(target, Session):
        raise ValueError('Duplicate event!')

def create(class_type, params):
    return _create(Session, class_type, params)

def update(instance, update_params):
    return _update(Session, instance, update_params)

def delete(instance):
    return _delete(Session, instance)

def create_list(class_type, params_list):
    return _create_list(Session, class_type, params_list)

def delete_list(instances):
    return _delete_list(Session, instances)

def delete_by_id(class_type, instance_id):
    return _delete_by_id(Session, class_type, instance_id)

def update_by_id(class_type, instance_id, update_params):
    return _update_by_id(Session, class_type, instance_id, update_params)

def get_by_id(user_id, organizer_id):
    return _get_by_id(Session, user_id, organizer_id)

def delete_following_row(class_type, params):
    return _delete_following_row(Session, class_type, params)
