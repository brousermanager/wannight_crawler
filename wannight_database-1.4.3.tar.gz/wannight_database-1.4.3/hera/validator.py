from fuzzywuzzy import fuzz
from sqlalchemy import text
from datetime import timedelta, datetime

from .schema import Event


def _validate_event(target: Event, Session):
    similar_events = read_similar_events(target, Session)
    if similar_events is None:
        return False
    for similar_event in similar_events:
        name_similarity = fuzz.ratio(target.name, similar_event.name)
        if name_similarity >= 55:
            return True
    return False


def read_similar_events(event: Event, Session) -> list[Event]:
    event_date_start = datetime.strptime(event.date_start, '%Y-%m-%d %H:%M:%S') \
        if type(event.date_start) == 'str' else event.date_start
    with Session() as session:
        return session.query(Event).filter(
            Event.city == event.city,
            text("event.date_start BETWEEN :start_date AND :end_date").params(
                start_date = event_date_start - timedelta(hours=12),
                end_date = event_date_start + timedelta(hours=12)
            )
        ).all()
