from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy import Column, ForeignKey, Integer, String, Float, Boolean, DateTime, Enum, Text, func, BigInteger

from .enum import LogProcess, LogType, CategoryType, UserStatus, SuggestionPlatform

# the metadata class each model inherits from.
# this also holds models' metadata for alembic 'autogenerate'
Base = declarative_base()

# "middle-class" between actual models and the Base class.
class BaseEntity(Base):
    __abstract__ = True

    def __repr__(self):
        attributes = [
            f"{attr}={getattr(self, attr)}"
            for attr in self.__dict__
            if getattr(self, attr) is not None and attr != '_sa_instance_state'
        ]
        return f"{self.__class__.__name__} {{{', '.join(attributes)}}}"


class Event(BaseEntity):
    __tablename__ = 'event'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    date_start = Column(DateTime, nullable=False)
    bot_feedback_up = Column(Integer, default=0)
    bot_feedback_down = Column(Integer, default=0)
    date_added = Column(DateTime, default=func.now())

    image = Column(Text)
    price = Column(Float)
    city = Column(String)
    fb_id = Column(String)
    address = Column(String)
    location = Column(String)
    ticket_url = Column(String)
    is_online = Column(Boolean)
    date_end = Column(DateTime)
    description = Column(String)
    n_interested = Column(Integer)

    event_arrangement = relationship('EventArrangement', cascade='all,delete', back_populates='event')
    user_event_feedback = relationship('UserEventFeedback', cascade='all,delete', back_populates='event')
    event_categorization = relationship('EventCategorization', cascade='all,delete', back_populates='event')
    user_event_notification = relationship('UserEventNotification', cascade='all,delete', back_populates='event')


class TelegramUser(BaseEntity):
    __tablename__ = 'telegram_user'

    telegram_id = Column(BigInteger, primary_key=True)
    privacy = Column(Boolean, default=False)
    nickname = Column(String, nullable=False)
    status = Column(Enum(UserStatus), default=UserStatus.NOT_VERIFIED)

    iva = Column(String)
    mail = Column(String)
    phone = Column(String)

    organizer = relationship('Organizer', back_populates='telegram_user')
    following = relationship('Following', back_populates='telegram_user')
    suggestion = relationship('Suggestion', back_populates='telegram_user')
    user_message = relationship('UserMessage', back_populates='telegram_user')
    user_preference = relationship('UserPreference', back_populates='telegram_user')
    user_event_feedback = relationship('UserEventFeedback', back_populates='telegram_user')
    user_event_notification = relationship('UserEventNotification', back_populates='telegram_user')


class UserEventNotification(BaseEntity):
    __tablename__ = 'user_event_notification'

    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey('event.id'))
    telegram_user_id = Column(BigInteger, ForeignKey('telegram_user.telegram_id'))

    event = relationship('Event', back_populates='user_event_notification')
    telegram_user = relationship('TelegramUser', back_populates='user_event_notification')


class FacebookOrganizer(BaseEntity):
    __tablename__ = 'facebook_organizer'

    id = Column(Integer, primary_key=True, autoincrement=True)
    url = Column(String, nullable=False)

    name = Column(String)
    likes = Column(Integer)
    category = Column(String)
    latitude = Column(String)
    longitude = Column(String)

    organizer = relationship('Organizer', back_populates='facebook_organizer')


class GoogleOrganizer(BaseEntity):
    __tablename__ = 'google_organizer'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    google_id = Column(String, nullable=True)

    city = Column(String)
    rating = Column(Float)
    address = Column(String)
    n_voters = Column(Integer)

    organizer = relationship('Organizer', back_populates='google_organizer')
    google_organizer_categorization = relationship('GoogleOrganizerCategorization', back_populates='google_organizer')


class CerberoOrganizer(BaseEntity):
    __tablename__ = 'cerbero_organizer'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    token = Column(String, nullable=False, unique=True)

    organizer = relationship('Organizer', back_populates='cerbero_organizer')


class Organizer(BaseEntity):
    __tablename__ = 'organizer'

    id = Column(Integer, primary_key=True, autoincrement=True)
    google_organizer_id = Column(Integer, ForeignKey('google_organizer.id'))
    cerbero_organizer_id = Column(Integer, ForeignKey('cerbero_organizer.id'))
    telegram_user_id = Column(BigInteger, ForeignKey('telegram_user.telegram_id'))
    facebook_organizer_id = Column(Integer, ForeignKey('facebook_organizer.id'))

    telegram_user = relationship('TelegramUser', back_populates='organizer', uselist=False)
    google_organizer = relationship('GoogleOrganizer', back_populates='organizer', uselist=False)
    cerbero_organizer = relationship('CerberoOrganizer', back_populates='organizer', uselist=False)
    facebook_organizer = relationship('FacebookOrganizer', back_populates='organizer', uselist=False)
    event_arrangement = relationship('EventArrangement', back_populates='organizer')
    following = relationship('Following', back_populates='organizer')


class EventArrangement(BaseEntity):
    __tablename__ = 'event_arrangement'

    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey('event.id'))
    organizer_id = Column(Integer, ForeignKey('organizer.id'))

    event = relationship('Event', back_populates='event_arrangement')
    organizer = relationship('Organizer', back_populates='event_arrangement')


class Category(BaseEntity):
    __tablename__ = 'category'

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    type = Column(Enum(CategoryType), nullable=False)

    user_preference = relationship('UserPreference', back_populates='category')
    event_categorization = relationship('EventCategorization', back_populates='category')
    google_organizer_categorization = relationship('GoogleOrganizerCategorization', back_populates='category')


class GoogleOrganizerCategorization(BaseEntity):
    __tablename__ = 'google_organizer_categorization'

    id = Column(Integer, primary_key=True, autoincrement=True)
    category_id = Column(Integer, ForeignKey('category.id'))
    google_organizer_id = Column(Integer, ForeignKey('google_organizer.id'))

    google_organizer = relationship('GoogleOrganizer', back_populates='google_organizer_categorization')
    category = relationship('Category', back_populates='google_organizer_categorization')


class EventCategorization(BaseEntity):
    __tablename__ = 'event_categorization'

    id = Column(Integer, primary_key=True, autoincrement=True)
    similar = Column(Float)
    event_id = Column(Integer, ForeignKey('event.id'))
    category_id = Column(Integer, ForeignKey('category.id'))

    event = relationship('Event', back_populates='event_categorization')
    category = relationship('Category', back_populates='event_categorization')


class UserEventFeedback(BaseEntity):
    __tablename__ = 'user_event_feedback'

    id = Column(Integer, primary_key=True, autoincrement=True)
    telegram_user_id = Column(BigInteger, ForeignKey('telegram_user.telegram_id'))
    event_id = Column(Integer, ForeignKey('event.id'))
    is_positive = Column(Boolean, nullable=False)

    event = relationship('Event', back_populates='user_event_feedback')
    telegram_user = relationship('TelegramUser', back_populates='user_event_feedback')


class UserMessage(BaseEntity):
    __tablename__ = 'user_message'

    id = Column(Integer, primary_key=True)
    step = Column(Integer, nullable=False)
    timestamp = Column(DateTime, default=func.now())
    telegram_user_id = Column(BigInteger, ForeignKey('telegram_user.telegram_id'), primary_key=True)

    telegram_user = relationship('TelegramUser', back_populates='user_message')


class UserPreference(BaseEntity):
    __tablename__ = 'user_preference'

    id = Column(Integer, primary_key=True)
    radius = Column(Integer)
    city = Column(String, nullable=False)
    auto = Column(Boolean, default=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    category_id = Column(Integer, ForeignKey('category.id'))
    telegram_user_id = Column(BigInteger, ForeignKey('telegram_user.telegram_id'))

    telegram_user = relationship('TelegramUser', back_populates='user_preference')
    category = relationship('Category', back_populates='user_preference', uselist=False)


class Log(BaseEntity):
    __tablename__ = 'log'

    id = Column(Integer, primary_key=True, autoincrement=True)
    message = Column(String, nullable=False)
    timestamp = Column(DateTime, default=func.now())
    type = Column(Enum(LogType), default=LogType.LOG)
    process = Column(Enum(LogProcess), nullable=False)


class Following(BaseEntity):
    __tablename__ = "following"

    id = Column(Integer, primary_key=True, autoincrement=True)
    id_user = Column(BigInteger, ForeignKey('telegram_user.telegram_id'))
    id_organizer = Column(Integer, ForeignKey('organizer.id'))
    
    telegram_user = relationship('TelegramUser', back_populates='following')
    organizer = relationship('Organizer', back_populates="following")


class Suggestion(BaseEntity):
    __tablename__ = "suggestion"

    id = Column(Integer, primary_key=True, autoincrement=True)
    url = Column(String, nullable=False)
    platform = Column(Enum(SuggestionPlatform), nullable=False)
    id_user = Column(BigInteger, ForeignKey('telegram_user.telegram_id'))

    telegram_user = relationship('TelegramUser', back_populates='suggestion')
