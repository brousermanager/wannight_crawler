from .schema import Following

def _create(Session, class_type, params):
    with Session() as session:
        new_instance = class_type(**params)
        session.add(new_instance)
        session.commit()
        session.refresh(new_instance)
        print(f"Creating => {new_instance}")
        return new_instance

def _update(Session, instance, update_params):
    with Session() as session:
        updated_instance = session.merge(instance)
        for key, value in update_params.items():
            setattr(updated_instance, key, value)
        session.commit()
        session.refresh(updated_instance)
        print(f"Updating => {updated_instance}")
        return updated_instance

def _delete(Session, instance):
    with Session() as session:
        print(f"Deleting => {instance}")
        session.delete(instance)
        session.commit()

def _create_list(Session, class_type, params_list):
    with Session() as session:
        new_instances = [class_type(**params) for params in params_list]
        session.add_all(new_instances)
        session.commit()
        for new_instance in new_instances:
            session.refresh(new_instance)
            print(f"Creating => {new_instance}")
        return new_instances

def _delete_list(Session, instances):
    with Session() as session:
        for instance in instances:
            print(f"Deleting => {instance}")
            session.delete(instance)
        session.commit()

def _delete_by_id(Session, class_type, instance_id):
    with Session() as session:
        instance = session.query(class_type).get(instance_id)
        if instance:
            print(f"Deleting => {instance}")
            session.delete(instance)
            session.commit()
            return True
        else:
            return False

# TODO: rivedi questo
def _update_by_id(Session, class_type, instance_id, update_params):
    with Session() as session:
        instance = session.query(class_type).get(instance_id)
        if instance:
            for key, value in update_params.items():
                if hasattr(instance, key):
                    setattr(instance, key, value)
                else:
                    raise ValueError(f"Attribute '{key}' does not exist in instance.")
            print(f"Updating => {instance}")
            session.commit()
            session.refresh(instance)
            return instance
        else:
            print(f"No instance with ID {instance_id} found.")
            return None

def _get_by_id(Session, class_type, instance_id):
    with Session() as session:
        return session.query(class_type).get(instance_id)
    
def _delete_following_row(Session, user_id, organizer_id):
    with Session() as session:
        try:
            # Cerca la riga con user_id e organizer_id specificati e elimina se trovata
            following_instance = session.query(Following).filter_by(id_user=user_id, id_organizer=organizer_id).one()
            print(f"Deleting => {following_instance}")
            session.delete(following_instance)
            session.commit()
        except:
            print(f"Row with user_id={user_id} and organizer_id={organizer_id} not found.")
