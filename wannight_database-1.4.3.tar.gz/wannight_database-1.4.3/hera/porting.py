import os
import pandas as pd
from pathlib import Path
from datetime import datetime
from sqlalchemy import inspect

from .crud import _create
from .schema import *

tables = {}

def _csv_export(engine, path: str):
    for table in get_tables_names(engine).keys():
        df = pd.read_sql(f'SELECT * FROM {table}', engine)
        if not df.empty:
            root_path = Path(path if path else os.getcwd())
            folder_path = root_path / datetime.now().strftime("%y%m%d-%H%M%S")
            os.makedirs(folder_path, exist_ok=True)
            save_path = folder_path / f'{table}.csv'
            df.replace('\n', '\t', regex=True).to_csv(save_path, index=False)

def _export_future_events(engine, path: str):
    current_datetime = datetime.now()
    formatted_current_date = current_datetime.strftime("%Y-%m-%d %H:%M:%S")
    query = f"""
        SELECT event.*, facebook_organizer.name AS facebook_name, facebook_organizer.url AS facebook_url
        FROM event
        JOIN event_arrangement ON event.id = event_arrangement.event_id
        JOIN organizer ON event_arrangement.organizer_id = organizer.id
        JOIN facebook_organizer ON organizer.facebook_organizer_id = facebook_organizer.id
        WHERE event.date_start >= '{formatted_current_date}'
    """
    df = pd.read_sql(query, engine)
    if not df.empty:
        root_path = Path(path if path else os.getcwd())
        folder_path = root_path / current_datetime.strftime("%y%m%d-%H%M%S")
        os.makedirs(folder_path, exist_ok=True)
        save_path = folder_path / 'future_events.csv'
        df.drop(columns=['id']).replace('\n', '\t', regex=True).to_csv(save_path, index=False)

# TODO: Serve una modifica per gli organizzatori multipli
def _import_future_events(Session, path: str):
    format1 = '%Y-%m-%d %H:%M:%S'
    format2 = '%Y-%m-%d %H:%M:%S.%f'
    for event in pd.read_csv(path).fillna(value='-None-').replace('\t', '\n', regex=True).to_dict(orient='records'):
        url = event.pop('facebook_url')
        name = event.pop('facebook_name')
        for key, value in event.items():
            new_value = value if value != '-None-' else None
            if  new_value is not None and key in ['date_start', 'date_end']:
                new_value = datetime.strptime(new_value, format1)
            if new_value is not None and key == 'date_added':
                new_value = datetime.strptime(new_value, format2)
            event[key] = new_value
        new_event = _create(Session, Event, event)
        if new_event:
            fb_organizer = get_organizer_by_url(Session, url)
            if not fb_organizer:
                fb_organizer = _create(Session, FacebookOrganizer, {
                    'url': url,
                    'name': name
                })
            organizer =  get_organizer_by_fb(Session, fb_organizer)
            if not organizer:
                organizer = _create(Session, Organizer, {
                    'facebook_organizer_id': fb_organizer.id
                })
            _create(Session, EventArrangement, {
                'event_id': new_event.id,
                'organizer_id': organizer.id
            })

def _csv_import(engine, Session, path: str):
    tables = get_tables_names(engine)
    files = os.listdir(path)
    table_names = []
    for file in files:
        name, extension = os.path.splitext(file)
        if extension =='.csv' and name in tables.keys():
            table_names.append(name)
    added_tables = []
    while len(table_names) > 0:
        for name in table_names:
            if exists_record(Session, tables[name]['entity']):
                raise Exception(f'La tabella {name} non è vuota')
            if len(tables[name]['relations']) == 0 or relations_check(tables[name]['relations'], added_tables, table_names):
                import_entity(engine, name, path)
                table_names.remove(name)
                added_tables.append(name)

def exists_record(Session, entity):
    with Session() as session:
        return session.query(globals()[entity]).count() != 0

def relations_check(relations, added_tables, table_names):
    referred_tables = [relation['referred_table'] for relation in relations]
    for table in set(referred_tables) & set(table_names):
        if not table in added_tables:
            return False
    return True

def import_entity(engine, name, path: str):
    folder_path = Path(path)
    file_path = folder_path / f"{name}.csv"
    df = pd.read_csv(file_path).replace('\t', '\n', regex=True).drop(columns=['id'])
    df.to_sql(name, engine, if_exists='append', index=False)

def get_tables_names(engine):
    inspector = inspect(engine)
    tables = {}
    for table in inspector.get_table_names():
        tables[table] = {
            'entity': snake_case_to_camel_case(table),
            'relations': inspector.get_foreign_keys(table)
        }
    return tables

def snake_case_to_camel_case(input_string):
    return ''.join(
        [word.capitalize() for word in input_string.split('_')]
    )

def get_organizer_by_url(Session, url):
    with Session() as session:
        return session.query(FacebookOrganizer).filter(
            FacebookOrganizer.url == url
        ).first()

def get_organizer_by_fb(Session, fb_organizer):
    with Session() as session:
        return session.query(Organizer).filter(
            Organizer.facebook_organizer_id == fb_organizer.id
        ).first()
