# Configurazione DB postgres locale

Creazione del container postgres

```bash
docker run --name wannight -e POSTGRES_PASSWORD=password -p 5432:5432 -d postgres
```

Successivamente accedi al terminale di questo container ed entra nella console di postgres

```bash
psql -U postgres
```

Infine crea il database

```sql
CREATE DATABASE wannight;
```

# Build del progetto

Effettua la build con il seguente comando

```bash
python -m build
```

# Installazione del pacchetto in altri progetti

Inserisci il file wannight_database-`version`.tar.gz nella root del progetto, successivamente esegui

```bash
pip install wannight_database-`version`.tar.gz
```

Ora puoi importare gli elementi dell pacchetto nel tuo progetto. Prima di interagire con il database ricorda sempre di configurare il db da utilizzare

```python
from hera import set_database

set_database('postgresql://postgres:password@localhost:5432/wannight')
```

Usa i comandi della libreria per interagire con le entità del database

```python
from hera.schema import TelegramUser
from hera import create, update, delete

user = create(TelegramUser, {'nickname': 'vanni'})
user = update(fb_org, {'nickname': 'vanni_bro'})
delete(user)
```

Usa le funzionalità di sqlalchemy per effettuare estrazioni dei dati a partire dalla sessione fornita da hera

```python
from hera import Session

with Session() as session:
    session.query(TelegramUser).filter(TelegramUser.id == 1).all()
```

# Esportazione

```python
csv_export_with_filter('google_organizer', (GoogleOrganizer.city == 'Molfetta'), True)

from datetime import datetime 
d = datetime.now()
csv_export_with_filter('event', (Event.date_start >= d), True)
```