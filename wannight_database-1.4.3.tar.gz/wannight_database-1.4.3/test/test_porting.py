from hera import set_database, csv_export

set_database('postgresql://postgres:password@localhost:5432/wannight')

csv_export('test/')