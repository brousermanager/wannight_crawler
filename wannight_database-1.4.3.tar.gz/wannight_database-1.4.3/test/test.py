from hera.schema import FacebookOrganizer, Organizer, Log, LogProcess
from hera import set_database, create, delete, update, create_list, delete_list

set_database('postgresql://postgres:password@localhost:5432/wannight')

fb_org = create(FacebookOrganizer, {'url': 'Vanni'})
fb_org1 = create(FacebookOrganizer, {'url': 'ZioFranco'})
org = create(Organizer, {'facebook_organizer_id':fb_org.id})

fb_org = update(fb_org, {'url': 'http://facebook.com/vanni', 'likes': 45})

delete(org)
delete(fb_org)
delete(fb_org1)

instances_to_create = [
    {"url": "value1", "likes": 30},
    {"url": "value3", "likes": 96}
]

created_instances = create_list(FacebookOrganizer, instances_to_create)

delete_list(created_instances)

create(Log, {'process': LogProcess.ATHENA, 'message': 'Test'})
