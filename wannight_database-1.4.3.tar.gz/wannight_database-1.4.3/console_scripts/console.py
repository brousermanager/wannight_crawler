#!/usr/bin/env python

import os
import code
from dotenv import load_dotenv

import hera
import hera.schema as schema
import hera.enum as enum

class CustomConsole(code.InteractiveConsole):
    def __init__(self, locals=None, filename="<console>"):
        super().__init__(locals, filename)
        self.commands = {
            "exit": self.command_exit
        }

    def command_exit(self):
        print("Uscita dalla console.")
        exit()

    def run_predefined_commands(self):
        load_dotenv()
        hera.set_database(os.environ.get('DATABASE_URL'))

    def interact(self, banner=None):
        self.run_predefined_commands()

        if banner is None:
            banner = "Console personalizzata avviata."
        
        self.banner = banner
        super().interact(banner=banner)

def main():
    console = CustomConsole(locals={
        'LogType': enum.LogType, 'LogProcess': enum.LogProcess, 'CategoryType': enum.CategoryType, 'UserStatus': enum.UserStatus,

        'UserEventFeedback': schema.UserEventFeedback, 'UserMessage': schema.UserMessage, 'Log': schema.Log, 'UserPreference': schema.UserPreference,
        'Event': schema.Event, 'TelegramUser': schema.TelegramUser, 'FacebookOrganizer': schema.FacebookOrganizer,
        'GoogleOrganizer': schema.GoogleOrganizer, 'CerberoOrganizer': schema.CerberoOrganizer, 'Organizer': schema.Organizer,
        'EventArrangement': schema.EventArrangement, 'Category': schema.Category, 'EventCategorization': schema.EventCategorization,
        'Following': schema.Following,

        'Session': hera.Session, 'create': hera.create, 'update': hera.update,
        'delete': hera.delete, 'create_list': hera.create_list, 'delete_list': hera.delete_list,
        'delete_by_id': hera.delete_by_id, 'update_by_id': hera.update_by_id, 'get_by_id': hera.get_by_id,
        'csv_import': hera.csv_import, 'csv_export': hera.csv_export,
        'export_future_events': hera.export_future_events, 'import_future_events': hera.import_future_events
    })
    console.interact()
